const Product = () => {
    return (
        <div>
            Produkt A
        </div>
    );
}

export default Product;