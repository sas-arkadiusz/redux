import Product from "./product/Product";

// Sluzy do wyświetlania wszystkich produktów
const Products = () => {
    return (
        <div>
            <div><Product /></div>
            <div><Product /></div>
        </div>  
    );
}

export default Products;